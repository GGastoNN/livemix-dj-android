#include <jni.h>
#include <atomic>
#include <algorithm>
#include <cmath>

class MixerDsp {
public:
    void cross(float x) {
        const float t = std::clamp((x + 1.0f) * 0.5f, 0.0f, 1.0f);
        crossA.store(std::cos(t * 1.57079632679f));
        crossB.store(std::sin(t * 1.57079632679f));
    }
    void gain(int deck, float value) { (deck == 0 ? gainA : gainB).store(std::clamp(value, 0.0f, 1.0f)); }
    void process(const float *a, const float *b, float *out, int frames) {
        const float ga=gainA.load()*crossA.load(), gb=gainB.load()*crossB.load();
        for(int i=0;i<frames*2;i++) out[i]=std::tanh(a[i]*ga+b[i]*gb);
    }
private:
    std::atomic<float> gainA{1}, gainB{1}, crossA{0.7071067f}, crossB{0.7071067f};
};

extern "C" JNIEXPORT jlong JNICALL Java_com_livemix_dj_NativeDspEngine_nativeCreate(JNIEnv*, jobject){ return reinterpret_cast<jlong>(new MixerDsp()); }
extern "C" JNIEXPORT void JNICALL Java_com_livemix_dj_NativeDspEngine_nativeDestroy(JNIEnv*, jobject, jlong h){ delete reinterpret_cast<MixerDsp*>(h); }
extern "C" JNIEXPORT void JNICALL Java_com_livemix_dj_NativeDspEngine_nativeSetCrossfader(JNIEnv*, jobject, jlong h, jfloat v){ reinterpret_cast<MixerDsp*>(h)->cross(v); }
extern "C" JNIEXPORT void JNICALL Java_com_livemix_dj_NativeDspEngine_nativeSetDeckGain(JNIEnv*, jobject, jlong h, jint d, jfloat v){ reinterpret_cast<MixerDsp*>(h)->gain(d,v); }
