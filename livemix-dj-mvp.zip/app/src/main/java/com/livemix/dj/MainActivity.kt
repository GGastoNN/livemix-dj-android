package com.livemix.dj

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private lateinit var engine: DeckEngine
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engine = DeckEngine(this)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Color.Cyan)) { Mixer(engine) } }
    }
    override fun onDestroy() { engine.release(); super.onDestroy() }
}

@Composable
private fun Mixer(engine: DeckEngine) {
    var crossfader by remember { mutableFloatStateOf(0f) }
    var targetLeft by remember { mutableStateOf(true) }
    var leftTrack by remember { mutableStateOf("TOCA CARGAR PARA ELEGIR AUDIO") }
    var rightTrack by remember { mutableStateOf("TOCA CARGAR PARA ELEGIR AUDIO") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { engine.load(targetLeft, it); val name = it.lastPathSegment?.substringAfterLast('/') ?: "Canción cargada"; if(targetLeft) leftTrack=name else rightTrack=name }
    }
    Surface(Modifier.fillMaxSize(), color = Color(0xFF090A0F)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("LIVEMIX DJ", style = MaterialTheme.typography.headlineMedium, color = Color.Cyan)
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                Deck("DECK A", leftTrack, Modifier.weight(1f), onLoad = { targetLeft = true; picker.launch(arrayOf("audio/*")) },
                    onPlay = { engine.toggle(true) }, onCue = { engine.jumpCue(true) }, onSetCue = { engine.storeCue(true) },
                    onPitch = { engine.setPitch(true, it) }, onScratchStart = { engine.beginScratch(true) },
                    onScratch = { engine.scratchBy(true, it) }, onScratchEnd = { engine.endScratch(true) }, onVolume={engine.setVolume(true,it)}, onSeek={engine.seekBy(true,it)}, accent = Color.Cyan)
                Deck("DECK B", rightTrack, Modifier.weight(1f), onLoad = { targetLeft = false; picker.launch(arrayOf("audio/*")) },
                    onPlay = { engine.toggle(false) }, onCue = { engine.jumpCue(false) }, onSetCue = { engine.storeCue(false) },
                    onPitch = { engine.setPitch(false, it) }, onScratchStart = { engine.beginScratch(false) },
                    onScratch = { engine.scratchBy(false, it) }, onScratchEnd = { engine.endScratch(false) }, onVolume={engine.setVolume(false,it)}, onSeek={engine.seekBy(false,it)}, accent = Color.Magenta)
            }
            Text("CROSSFADER", color = Color.LightGray)
            Slider(value = crossfader, onValueChange = { crossfader = it; engine.crossfade(it) }, valueRange = -1f..1f)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("A", color=Color.Cyan); Text("B", color=Color.Magenta) }
        }
    }
}

@Composable
private fun Deck(title: String, track: String, modifier: Modifier, onLoad: () -> Unit, onPlay: () -> Unit,
                 onCue: () -> Unit, onSetCue: () -> Unit, onPitch: (Float) -> Unit,
                 onScratchStart: () -> Unit, onScratch: (Float) -> Unit, onScratchEnd: () -> Unit,
                 onVolume: (Float) -> Unit, onSeek: (Long) -> Unit,
                 accent: Color) {
    var pitch by remember { mutableFloatStateOf(0f) }
    var volume by remember { mutableFloatStateOf(1f) }
    Card(modifier.fillMaxHeight()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, style = MaterialTheme.typography.headlineSmall)
            Text(track, color=accent, maxLines=1, overflow=TextOverflow.Ellipsis)
            FilledTonalButton(onClick = onLoad, modifier=Modifier.fillMaxWidth()) { Text("＋ CARGAR CANCIÓN") }
            VinylJog(accent = accent, onScratchStart = onScratchStart, onScratch = onScratch, onScratchEnd = onScratchEnd)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { onSeek(-10_000) }) { Text("−10s") }
                Button(onClick = onPlay) { Text("PLAY / PAUSA") }
                OutlinedButton(onClick = { onSeek(10_000) }) { Text("+10s") }
                OutlinedButton(onClick = onCue) { Text("CUE") }
                OutlinedButton(onClick = onSetCue) { Text("SET CUE") }
            }
            Text("Pitch ${"%.1f".format(pitch)} %")
            Slider(value = pitch, onValueChange = { pitch = it; onPitch(it) }, valueRange = -16f..16f)
            Text("Volumen ${"%.0f".format(volume*100)}%")
            Slider(value=volume,onValueChange={volume=it;onVolume(it)},valueRange=0f..1f)
            Text("VINYL · SCRATCH", color = accent, style = MaterialTheme.typography.labelMedium)
        }
    }
}
