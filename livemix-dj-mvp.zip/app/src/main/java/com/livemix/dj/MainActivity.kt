package com.livemix.dj

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private lateinit var engine: DeckEngine
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engine = DeckEngine(this)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Color.Cyan)) { Mixer(engine) } }
    }
    override fun onDestroy() { engine.release(); super.onDestroy() }
}

@Composable
private fun Mixer(engine: DeckEngine) {
    var crossfader by remember { mutableFloatStateOf(0f) }
    var targetLeft by remember { mutableStateOf(true) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { engine.load(targetLeft, it) }
    }
    Surface(Modifier.fillMaxSize(), color = Color(0xFF090A0F)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("LIVEMIX DJ", style = MaterialTheme.typography.headlineMedium, color = Color.Cyan)
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                Deck("DECK A", Modifier.weight(1f), onLoad = { targetLeft = true; picker.launch(arrayOf("audio/*")) },
                    onPlay = { engine.toggle(true) }, onCue = { engine.jumpCue(true) }, onSetCue = { engine.storeCue(true) },
                    onPitch = { engine.setPitch(true, it) })
                Deck("DECK B", Modifier.weight(1f), onLoad = { targetLeft = false; picker.launch(arrayOf("audio/*")) },
                    onPlay = { engine.toggle(false) }, onCue = { engine.jumpCue(false) }, onSetCue = { engine.storeCue(false) },
                    onPitch = { engine.setPitch(false, it) })
            }
            Text("CROSSFADER", color = Color.LightGray)
            Slider(value = crossfader, onValueChange = { crossfader = it; engine.crossfade(it) }, valueRange = -1f..1f)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("A", color=Color.Cyan); Text("B", color=Color.Magenta) }
        }
    }
}

@Composable
private fun Deck(title: String, modifier: Modifier, onLoad: () -> Unit, onPlay: () -> Unit,
                 onCue: () -> Unit, onSetCue: () -> Unit, onPitch: (Float) -> Unit) {
    var pitch by remember { mutableFloatStateOf(0f) }
    Card(modifier.fillMaxHeight()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, style = MaterialTheme.typography.headlineSmall)
            Button(onClick = onLoad) { Text("CARGAR CANCIÓN") }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onPlay) { Text("PLAY / PAUSA") }
                OutlinedButton(onClick = onCue) { Text("CUE") }
                OutlinedButton(onClick = onSetCue) { Text("SET CUE") }
            }
            Text("Pitch ${"%.1f".format(pitch)} %")
            Slider(value = pitch, onValueChange = { pitch = it; onPitch(it) }, valueRange = -16f..16f)
            Spacer(Modifier.weight(1f))
            Text("Waveform y BPM: próxima iteración", color = Color.Gray)
        }
    }
}
