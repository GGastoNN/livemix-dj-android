package com.livemix.dj

object MidiMapping {
    const val STATUS_CONTROL_CHANGE = 0xB0
    const val CROSSFADER_CC = 8
    const val LEFT_PLAY_CC = 20
    const val RIGHT_PLAY_CC = 21

    fun normalize7Bit(value: Int): Float = (value.coerceIn(0, 127) / 63.5f) - 1f
}
