package com.livemix.dj

import android.content.Context
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiManager

class MidiController(context: Context, private val onCc: (Int, Int) -> Unit) {
    private val manager = context.getSystemService(MidiManager::class.java)
    val devices: List<MidiDeviceInfo> get() = manager.devices.toList()

    // Android expone aquí tanto MIDI USB class-compliant como BLE MIDI emparejado.
    // La apertura de puertos y MidiReceiver se añadirá junto al editor de mappings.
    fun refresh(): List<String> = devices.map { info ->
        info.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "MIDI ${info.id}"
    }

    fun previewCc(controller: Int, value: Int) = onCc(controller, value)
}
