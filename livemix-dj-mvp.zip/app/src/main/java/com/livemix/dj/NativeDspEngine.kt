package com.livemix.dj

class NativeDspEngine : AutoCloseable {
    private var handle: Long = nativeCreate()
    fun setCrossfader(value: Float) { if (handle != 0L) nativeSetCrossfader(handle, value) }
    fun setDeckGain(deck: Int, value: Float) { if (handle != 0L) nativeSetDeckGain(handle, deck, value) }
    override fun close() { if (handle != 0L) { nativeDestroy(handle); handle = 0 } }
    private external fun nativeCreate(): Long
    private external fun nativeDestroy(handle: Long)
    private external fun nativeSetCrossfader(handle: Long, value: Float)
    private external fun nativeSetDeckGain(handle: Long, deck: Int, value: Float)
    companion object { init { System.loadLibrary("livemix_audio") } }
}
