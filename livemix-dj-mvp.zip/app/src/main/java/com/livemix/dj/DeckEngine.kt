package com.livemix.dj

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.exoplayer.ExoPlayer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

class DeckEngine(context: Context) {
    val nativeDsp = NativeDspEngine()
    val left = ExoPlayer.Builder(context).build()
    val right = ExoPlayer.Builder(context).build()
    private var leftCue = 0L
    private var rightCue = 0L
    private var leftWasPlaying = false
    private var rightWasPlaying = false

    fun load(isLeft: Boolean, uri: Uri) {
        player(isLeft).apply { setMediaItem(MediaItem.fromUri(uri)); prepare() }
    }
    fun toggle(isLeft: Boolean) = player(isLeft).let { if (it.isPlaying) it.pause() else it.play() }
    fun seekBy(isLeft: Boolean, milliseconds: Long) = player(isLeft).let { it.seekTo((it.currentPosition + milliseconds).coerceAtLeast(0L)) }
    fun setVolume(isLeft: Boolean, value: Float) { player(isLeft).volume = value.coerceIn(0f, 1f); nativeDsp.setDeckGain(if(isLeft) 0 else 1, value) }
    fun setPitch(isLeft: Boolean, value: Float) {
        val speed = (1f + value / 100f).coerceIn(.5f, 2f)
        player(isLeft).playbackParameters = PlaybackParameters(speed)
    }
    fun storeCue(isLeft: Boolean) { if (isLeft) leftCue = left.currentPosition else rightCue = right.currentPosition }
    fun jumpCue(isLeft: Boolean) = player(isLeft).seekTo(if (isLeft) leftCue else rightCue)
    fun beginScratch(isLeft: Boolean) {
        val deck = player(isLeft)
        if (isLeft) leftWasPlaying = deck.isPlaying else rightWasPlaying = deck.isPlaying
        deck.pause()
    }
    fun scratchBy(isLeft: Boolean, deltaDegrees: Float) {
        val deck = player(isLeft)
        // Un vinilo a 33 1/3 RPM recorre unos 1.8 s por vuelta.
        val deltaMs = (deltaDegrees * 5f).toLong()
        deck.seekTo((deck.currentPosition + deltaMs).coerceIn(0L, deck.duration.coerceAtLeast(0L)))
    }
    fun endScratch(isLeft: Boolean) {
        if ((isLeft && leftWasPlaying) || (!isLeft && rightWasPlaying)) player(isLeft).play()
    }
    fun crossfade(value: Float) {
        nativeDsp.setCrossfader(value)
        val t = ((value + 1f) / 2f).coerceIn(0f, 1f)
        left.volume = cos(t * PI.toFloat() / 2f)
        right.volume = sin(t * PI.toFloat() / 2f)
    }
    fun release() { nativeDsp.close(); left.release(); right.release() }
    private fun player(isLeft: Boolean) = if (isLeft) left else right
}
