package com.livemix.dj

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.exoplayer.ExoPlayer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

class DeckEngine(context: Context) {
    val left = ExoPlayer.Builder(context).build()
    val right = ExoPlayer.Builder(context).build()
    private var leftCue = 0L
    private var rightCue = 0L

    fun load(isLeft: Boolean, uri: Uri) {
        player(isLeft).apply { setMediaItem(MediaItem.fromUri(uri)); prepare() }
    }
    fun toggle(isLeft: Boolean) = player(isLeft).let { if (it.isPlaying) it.pause() else it.play() }
    fun setPitch(isLeft: Boolean, value: Float) {
        val speed = (1f + value / 100f).coerceIn(.5f, 2f)
        player(isLeft).playbackParameters = PlaybackParameters(speed)
    }
    fun storeCue(isLeft: Boolean) { if (isLeft) leftCue = left.currentPosition else rightCue = right.currentPosition }
    fun jumpCue(isLeft: Boolean) = player(isLeft).seekTo(if (isLeft) leftCue else rightCue)
    fun crossfade(value: Float) {
        val t = ((value + 1f) / 2f).coerceIn(0f, 1f)
        left.volume = cos(t * PI.toFloat() / 2f)
        right.volume = sin(t * PI.toFloat() / 2f)
    }
    fun release() { left.release(); right.release() }
    private fun player(isLeft: Boolean) = if (isLeft) left else right
}
