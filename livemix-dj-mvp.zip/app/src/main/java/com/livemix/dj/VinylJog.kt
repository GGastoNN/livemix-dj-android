package com.livemix.dj

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun VinylJog(
    accent: Color,
    onScratchStart: () -> Unit,
    onScratch: (Float) -> Unit,
    onScratchEnd: () -> Unit
) {
    var rotation by remember { mutableFloatStateOf(0f) }
    var previousAngle by remember { mutableFloatStateOf(0f) }

    Canvas(
        Modifier
            .size(150.dp)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { point ->
                        previousAngle = angle(point, size.width / 2f, size.height / 2f)
                        onScratchStart()
                    },
                    onDragEnd = onScratchEnd,
                    onDragCancel = onScratchEnd
                ) { change, _ ->
                    val next = angle(change.position, size.width / 2f, size.height / 2f)
                    var delta = next - previousAngle
                    if (delta > 180f) delta -= 360f
                    if (delta < -180f) delta += 360f
                    rotation = (rotation + delta) % 360f
                    previousAngle = next
                    onScratch(delta)
                    change.consume()
                }
            }
    ) {
        val center = this.center
        val radius = size.minDimension / 2f
        drawCircle(Color(0xFF050507), radius)
        repeat(14) { ring ->
            drawCircle(Color(0xFF24262D), radius * (0.34f + ring * 0.043f), style = Stroke(1.2f))
        }
        drawCircle(Color(0xFF11131A), radius * .33f)
        drawCircle(accent.copy(alpha = .85f), radius * .23f)
        drawCircle(Color(0xFF08090C), radius * .055f)

        val markerAngle = (rotation - 90f) * PI.toFloat() / 180f
        val markerRadius = radius * .78f
        drawCircle(
            color = Color.White,
            radius = radius * .035f,
            center = Offset(
                center.x + cos(markerAngle) * markerRadius,
                center.y + sin(markerAngle) * markerRadius
            )
        )
        drawCircle(accent.copy(alpha = .32f), radius, style = Stroke(5f))
    }
}

private fun angle(point: Offset, centerX: Float, centerY: Float): Float =
    atan2(point.y - centerY, point.x - centerX) * 180f / PI.toFloat()
